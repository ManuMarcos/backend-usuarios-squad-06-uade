package com.reparaya.users.util;

public enum RegisterOriginEnum {
    WEB_USUARIOS,
    CATALOGO,
    BUSQUEDA_SOLICITUDES
}
