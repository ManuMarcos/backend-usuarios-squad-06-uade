package com.reparaya.users.dto;

import lombok.Data;

@Data
public class ResetPasswordRequest {
    private String newPassword;
}
