package com.reparaya.users.dto;

import lombok.Data;

@Data
public class UserChangeActiveRequest {
    private boolean active;
}
